### 重要的事情说三次，自用、自用、自用。
<h4 align="center">访客数 :eyes:</h4>
<p align="center">
<img  src="https://profile-counter.glitch.me/Actions-360v6/count.svg" alt="Sub :: Visitor's Count" />
 <img width=0 height=0 src="https://profile-counter.glitch.me/wwz09/count.svg" alt="wwz09:: Visitor's Count" />
</p>

### 固件发布:

[![Total](https://shields.io/github/downloads/wwz09/Actions-360v6/total?logo=Bookmeter&label=releases&logoColor=yellow&color=yellow)](https://github.com/wwz09/Actions-360v6/releases)

[![Download](https://img.shields.io/github/v/release/wwz09/Actions-360v6?color=orange&logoColor=orange&label=Download&logo=DocuSign)](https://github.com/wwz09/Actions-360v6/releases/latest) 


### 固件编译壮态：

| [![](https://img.shields.io/badge/360v6-纯净版-32C955.svg?logo=openwrt)](https://github.com/wwz09/Actions-360v6/blob/main/.github/workflows/360V6-cj.yml) | [![](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-cj.yml/badge.svg)](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-cj.yml)  | [![](https://img.shields.io/badge/下载-链接-blueviolet.svg?logo=hack-the-box)](https://github.com/wwz09/Actions-360v6/releases?q=360v6纯净版&expanded=true) | [![](https://img.shields.io/badge/编译-配置-orange.svg?logo=apache-spark)](https://github.com/wwz09/Actions-360v6/blob/main/config/360V6.config) 
* 管理地址：192.168.3.1  帐号：root   密码：password 

| [![](https://img.shields.io/badge/360v6-测试版-32C955.svg?logo=openwrt)](https://github.com/wwz09/Actions-360v6/blob/main/.github/workflows/360V6-cs.yml) | [![](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-cs.yml/badge.svg)](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-cs.yml)  | [![](https://img.shields.io/badge/下载-链接-blueviolet.svg?logo=hack-the-box)](https://github.com/wwz09/Actions-360v6/releases?q=360v6测试版&expanded=true) | [![](https://img.shields.io/badge/编译-配置-orange.svg?logo=apache-spark)](https://github.com/wwz09/Actions-360v6/blob/main/config/360V6.config) 
* 管理地址：192.168.3.1  帐号：root   密码：password
 
| [![](https://img.shields.io/badge/360v6-自用版-32C955.svg?logo=openwrt)](https://github.com/wwz09/Actions-360v6/blob/main/.github/workflows/360V6-zy.yml) | [![](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-zy.yml/badge.svg)](https://github.com/wwz09/Actions-360v6/actions/workflows/360V6-zy.yml)  | [![](https://img.shields.io/badge/下载-链接-blueviolet.svg?logo=hack-the-box)](https://github.com/wwz09/Actions-360v6/releases?q=360v6自用版&expanded=true) | [![](https://img.shields.io/badge/编译-配置-orange.svg?logo=apache-spark)](https://github.com/wwz09/Actions-360v6/blob/main/config/360V6.config) 
* 管理地址：192.168.2.1  帐号：root    
